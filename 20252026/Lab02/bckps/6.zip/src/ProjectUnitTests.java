import org.junit.jupiter.api.Test;


public class ProjectUnitTests {
    @Test
    public void testConstructor() {
    }
    
    @Test
    public void testConstructor2() {
    }
}
