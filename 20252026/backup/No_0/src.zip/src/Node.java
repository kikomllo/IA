public class Node{
    private Node[] children;
    private Node parent;
    private int value;

    public Node(int value, Node parent){
        this.value = value;
        this.parent = parent;
    }

    public Node(int value){
        this.value = value;
        this.parent = null;
    }

    public int value() {
        return value;
    }

    public Node parent() {
        return parent;
    }

    public Node[] getChildren() {
        return children;
    }

    public Node[] children(){
        this.children = new Node[]{
                new Node(value*2, this),
                new Node(value*2+1, this)
        };
        return children;
    }

    @Override
    public String toString() {
        return "" + value;
    }
}
