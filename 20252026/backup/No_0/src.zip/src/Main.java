import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main{
    public static Node createTree(Node start, int end){
        ArrayList<Node> list = new ArrayList<>();
        Node current_node = start;

        while(current_node.value() != end){
            if (current_node.value() > end) throw new IndexOutOfBoundsException();

            list.addAll(List.of(current_node.children()));
            list.removeFirst();
            current_node = list.getFirst();
        }

        return current_node;
    }

    public static ArrayList<Node> getOrder(Node end){
        ArrayList<Node> path = new ArrayList<>();
        while(end != null){
            path.addFirst(end);
            end = end.parent();
        }

        return path;
    }

    static void main() throws IOException {
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        int start, end;

        start = Integer.parseInt(bf.readLine());
        end = Integer.parseInt(bf.readLine());

        Node endNode = createTree(new Node(start), end);
        for(Node node : getOrder(endNode)){
            System.out.println(node.value());
        }
    }
}
