package math;

import java.util.Arrays;
import java.util.Objects;
import java.util.Random;
import java.util.function.BiFunction;
import java.util.function.Function;

/**
 * @author hdaniel@ualg.pt
 * @version 202511052002
 */
public class Matrix {

    private double[][] data;
    private int rows, cols;

    public Matrix(int rows, int cols) {
        data = new double[rows][cols];
        this.rows = rows;
        this.cols = cols;
    }


    public Matrix(double[][] data) {
        this.rows = data.length;
        this.cols = data[0].length;
        this.data = new double[rows][cols];
        for (int i = 0; i < rows; i++)
            System.arraycopy(data[i], 0, this.data[i], 0, cols);

    }


    static public Matrix Rand(int rows, int cols, Random rnd, double[] sampleLimits) {
        Matrix out = new Matrix(rows, cols);
        double sampleSize = sampleLimits[1] - sampleLimits[0];

        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                out.data[i][j] = (rnd.nextDouble() * sampleSize) +sampleLimits[0];

        return out;
    }


    //accessors
    public double get(int row, int col) {
        return data[row][col];
    }
    public int rows() { return rows; }
    public int cols() { return cols; }
    public double[][] data() { return data; }


    //==============================================================
    //  Element operations
    //==============================================================

    //Apply Function<Double, Double> to all elements of the matrix
    //store the result in matrix result
    private Matrix traverse(Function<Double, Double> fnc) {
        Matrix result = new Matrix(rows, cols);

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.data[i][j] = fnc.apply(data[i][j]);
            }
        }
        return result;
    }

    public Matrix apply(Function<Double, Double> fnc) {
        return traverse(fnc);
    }

    //multiply matrix by scalar
    public Matrix mult(double scalar) {
        double[][] new_data = new double[rows][cols];

        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                new_data[i][j] = data[i][j] * scalar;

        return new Matrix(new_data);
    }

    //add scalar to matrix
    public Matrix add(double scalar) {
        double[][] new_data = new double[rows][cols];

        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                new_data[i][j] = data[i][j] + scalar;

        return new Matrix(new_data);
    }

    //sub matrix from scalar:   scalar - M
    public Matrix subFromScalar(double scalar) {
        double[][] new_data = new double[rows][cols];

        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                new_data[i][j] = scalar - data[i][j];

        return new Matrix(new_data);
    }


    //==============================================================
    //  Element-wise operations between two matrices
    //==============================================================

    //Element wise operation
    private Matrix elementWise(Matrix other, BiFunction<Double, Double, Double> fnc) {
        if (this.rows != other.rows || this.cols != other.cols) {
            throw new IllegalArgumentException("Incompatible matrix sizes for element wise.");
        }

        Matrix result = new Matrix(rows, cols);

        //add element by element
        //store the result in matrix result
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++)
                result.data[i][j] = fnc.apply(this.data[i][j], other.data[i][j]);
        }
        return result;
    }

    //add two matrices
    public Matrix add(Matrix other) {
        return this.elementWise(other, (a, b) -> a + b);
    }

    //multiply two matrices (element wise)
    public Matrix mult(Matrix other) {
        return this.elementWise(other, (a, b) -> a * b);
    }

    //sub two matrices
    public Matrix sub(Matrix other) {
        return this.elementWise(other, (a, b) -> a - b);
    }


    //==============================================================
    //  Other math operations
    //==============================================================

    //sum all elements of the matrix
    public double sum() {
        double total = 0.0;

        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                total += data[i][j];


        return total;
    }


    //Sum by columns
    public Matrix sumColumns() {
        Matrix result = new Matrix(1, this.cols);

        for (int j = 0; j < this.cols; j++) {
            double sum = 0.0;
            for (int i = 0; i < this.rows; i++)
                sum += this.data[i][j];
            result.data[0][j] = sum;
        }
        return result;
    }

    
    //multiply two matrices (dot product)
    public Matrix dot(Matrix other) {
        if (this.cols != other.rows) {
            System.out.println(this.cols + " " + other.rows);
            throw new IllegalArgumentException("Incompatible matrix sizes for multiplication.");
        }

        Matrix result = new Matrix(this.rows, other.cols);

        //multiply 2 matrices
        //store the result in matrix result
        for (int i = 0; i < this.rows; i++) {
            for (int j = 0; j < other.cols; j++) {
                for (int k = 0; k < this.cols; k++) {
                    result.data[i][j] += this.data[i][k] * other.data[k][j];
                }
            }
        }
        return result;
    }


    //Add row vector to each row of the matrix
    public Matrix addRowVector(Matrix rowVector) {
        if (rowVector.rows() != 1 || rowVector.cols() != this.cols) {
            System.out.println(rowVector.rows() + " " + rowVector.cols() + " " + this.cols);
            throw new IllegalArgumentException("Incompatible sizes for adding row vector.");
        }

        Matrix result = new Matrix(this.rows, this.cols);

        //add row vector to each row
        for (int i = 0; i < this.rows; i++) {
            for (int j = 0; j < this.cols; j++) {
                result.data[i][j] = this.data[i][j] + rowVector.data[0][j];
            }
        }
        return result;
    }


    //==============================================================
    //  Column and row operations
    //==============================================================

    //transpose matrix
    public Matrix transpose() {
        Matrix result = new Matrix(cols, rows);

        //transpose the matrix
        //store the result in matrix result
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.data[j][i] = data[i][j];
            }
        }
        return result;
    }

    public void swapRows(int a, int b){
        double[] backup = data[a];
        data[a] = data[b];
        data[b] = backup;
    }

    public void swapCols(int a, int b){
        for(int i = 0; i < rows(); i++){
            double backup = data[i][a];
            data[i][a] = data[i][b];
            data[i][b] = backup;
        }
    }

    public static void shufflePair(Matrix X, Matrix Y){
        Random rand = new Random(System.currentTimeMillis());
        for (int i = X.rows() - 1; i > 0; i--) {
            int j = rand.nextInt(i + 1);

            X.swapRows(i, j);
            Y.swapRows(i, j);
        }
    }


    //==============================================================
    //  Convert operations
    //==============================================================

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (double[] row : data) {
            for (double val : row) {
                sb.append(String.format("%.3f ", val));
            }
            sb.append("\n");
        }
        return sb.toString();
    }
    

    //==============================================================
    //  Compare operations
    //==============================================================

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Matrix matrix)) return false;
        return rows == matrix.rows && cols == matrix.cols && Objects.deepEquals(data, matrix.data);
    }

    @Override
    public Matrix clone(){
        return new Matrix(data);
    }

    @Override
    public int hashCode() {
        return Objects.hash(Arrays.deepHashCode(data), rows, cols);
    }
}
